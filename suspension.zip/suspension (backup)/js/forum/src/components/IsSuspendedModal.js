import Modal from 'flarum/components/Modal';

export default class IsSuspendedModal extends Modal {
  className() {
    return 'ChangePasswordModal Modal--small';
  }

  title() {
    return app.translator.trans('flarum-suspend.forum.is_suspended.title');
  }

  content() {
    return (
      <div className="Modal-body">
        <div className="Form Form--centered">
          <p className="helpText">{app.translator.trans('flarum-suspend.forum.is_suspended.suspension_text', {days: this.props.user.suspendUntil()})}</p>
        </div>
      </div>
    );
  }
}
