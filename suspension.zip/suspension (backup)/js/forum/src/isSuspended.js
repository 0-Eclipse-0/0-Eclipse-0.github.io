import { extend } from 'flarum/extend';
import app from 'flarum/app';
import User from 'flarum/models/User';

import SuspendUserModal from 'flarum/suspend/components/IsSuspendedModal';

export default function isSuspended() {
  let until = this.props.user.suspendUntil();

  if (new Date() > until) until = null;

  if (until != null) {
    console.log("[SuspensionTest] User is suspended!");
    app.modal.show(new IsSuspendedModal({user}));
  } else {
    console.log("[SuspensionTest] User is not suspended!");
  }
}
